This is a 1 page website. if you click any items from menu, you
will visit that portion in the same page. 
here, 
6 sections;
header- menu, logo, background image
footer- copyright
about us
service- 6 services- 6 images, overlay, description
team members- 4 members- 4 images, overlay, list icon, description
contact- form- email, name, submit 

every section will have some common properties
common div classes- container class, section title class

responsiveness-
desktop 
tab
mobile

section for header and footer  is available tag in header and footer

add meta viewport for different language support
add another meta with scale, content for responsiveness support

change the background color of the selected images
remove background and then
add white background color
make background color transparent for logo

